﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_de_tareas
{
    public partial class Form1 : Form
    {
        Conexionbd conexion = new Conexionbd();
        public Form1()
        {
            InitializeComponent();
            Conexionbd conexion = new Conexionbd();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonL_Click(object sender, EventArgs e)
        {
            string us = UsuarioText.Text;
            string co = ContraseñaText.Text;
           

          
                conexion.login(us, co);
 
                UsuarioText.Clear();
                ContraseñaText.Clear();
             

           
           
        }
    }
}
