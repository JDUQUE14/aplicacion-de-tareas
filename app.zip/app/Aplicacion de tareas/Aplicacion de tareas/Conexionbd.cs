﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Diagnostics.Contracts;


namespace Aplicacion_de_tareas
{
    public class Conexionbd
    { 
        string cadena = "Data Source=DESKTOP-71D4CHF\\MSSQLSERVER01;Initial Catalog=TareasDB;Integrated Security=True";
        public SqlConnection conectar= new SqlConnection();
        public SqlCommand comando = new SqlCommand();


        
        public Conexionbd ()
        {
            conectar.ConnectionString = cadena;
        }

        public void login(string usuario,string contraseña)
        {
            try {
                
                conectar.Open();

                string consulta = "select * from Usuarios where nombreUsuario='" + usuario + "' and contrasena='" + contraseña + "'";
                SqlCommand comando = new SqlCommand(consulta, conectar);
                SqlDataReader lector;
                lector = comando.ExecuteReader();

                if (lector.HasRows == true)
                {
                    MessageBox.Show("Bienvenido :)");
                    App app = new App(usuario);
                    app.Show();
                

                }

                else
                {
                    MessageBox.Show("Usuario o Contraseña Incorrectas");
                }
                conectar.Close();
            }
            catch (Exception ex){
                MessageBox.Show("fallido  "+ex.Message);
            }
        }

        public void agregar(string titulo,string descripcion, string fecha,int estado,int cate,string u)
        {
            conectar.Open();
            string consulta = "INSERT INTO Tareas(titulo,descripcion,categoriaid,usuarioid,estadoid,fechaVencimiento) values('"+titulo+"','"+descripcion+ "',( select ID from Categorias where ID="+cate+ "),( select ID from Usuarios where nombreUsuario='"+u+ "'),( select ID from Estados where ID=" + estado+"),'" + fecha+ "')";
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();
            conectar.Close();
        }

        public void editar(string titulo, string descripcion, string fecha,int id,int estado,int cate,string u)
        {
            conectar.Open();

            string consulta = "update Tareas set titulo='"+titulo+ "',descripcion='"+descripcion+ "',categoriaid=( select ID from Categorias where ID="+cate+ "),usuarioid=( select ID from Usuarios where nombreUsuario='"+u+ "'),estadoid=( select ID from Estados where ID=" + estado + "),fechaVencimiento='" + fecha+"' where ID="+id;
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();


            conectar.Close();

        }

        public void eliminar(int id)
        {
            conectar.Open();

            string consulta = "delete from Tareas where ID=" + id;
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();


            conectar.Close();

        }

        public void add(string nombre,string descripcion,string fe)
        {
            conectar.Open();
            string consulta = "INSERT INTO Categorias(nombre,descripcion,fechaCreacion) values('" + nombre + "','" + descripcion + "','"+fe+"')";
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();
            conectar.Close();
        }

        public void edi(string nombre,string descripcion,string fecha,int id)
        {
            conectar.Open();

            string consulta = "update Categorias set nombre='" + nombre + "',descripcion='" + descripcion + "',fechaCreacion='" + fecha + "' where ID=" + id;
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();
           


            conectar.Close();
        }

        public void delete(int id)
        {
            conectar.Open();

            string consulta = "delete from Categorias where ID=" + id;
            SqlCommand comando = new SqlCommand(consulta, conectar);
            comando.ExecuteNonQuery();

            conectar.Close();

        }




    }
}
