﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_de_tareas
{
    public partial class App : Form

    {
        string cadena = "Data Source=DESKTOP-71D4CHF\\MSSQLSERVER01;Initial Catalog=TareasDB;Integrated Security=True";
        Conexionbd conexion = new Conexionbd();
        public string uss;
        public void actualizartb()
        {
            string consulta = "select * from Tareas";
            SqlDataAdapter adapter = new SqlDataAdapter(consulta, cadena);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            Vista.DataSource = dt;

        }
        public App(string us)
        {
            uss = us;
            InitializeComponent();
            actualizartb();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Vista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string titulo = TituloTarea.Text;
            string des = Descripcion.Text;
            string fecha= Fecha.Value.ToString("yyyy-MM-dd");
            int estado,cate;
            string us = uss;
           
            int.TryParse(Estado.Text, out estado);
            int.TryParse(Categoria.Text, out cate);
            conexion.agregar(titulo,des,fecha,estado,cate,us);
            actualizartb();
        }

        private void App_Load(object sender, EventArgs e)
        {

        }

        private void Vista_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int indice = e.RowIndex;
            ided.Text = Vista.Rows[indice].Cells[0].Value.ToString();
            TituloTarea.Text = Vista.Rows[indice].Cells[1].Value.ToString();
            Descripcion.Text = Vista.Rows[indice].Cells[2].Value.ToString();
            Categoria.Text = Vista.Rows[indice].Cells[3].Value.ToString();
            Estado.Text = Vista.Rows[indice].Cells[5].Value.ToString();
            Fecha.Text = Vista.Rows[indice].Cells[7].Value.ToString();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            string titulo = TituloTarea.Text;
            string des = Descripcion.Text;
            string fecha = Fecha.Value.ToString("yyyy-MM-dd");
            int id,estado,cate;
            string us = uss;
            int.TryParse(ided.Text, out id);
            int.TryParse(Estado.Text, out estado);
            int.TryParse(Categoria.Text, out cate);

            conexion.editar(titulo, des, fecha,id,estado,cate,us);
            actualizartb();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int id;
            int.TryParse(ided.Text, out id);
            conexion.eliminar(id);
            actualizartb();
        }

        private void btnc_Click(object sender, EventArgs e)
        {
            string us = uss;
            categorias cat = new categorias(us);
            this.Hide();
            cat.Show();
        }
    }
}
                        