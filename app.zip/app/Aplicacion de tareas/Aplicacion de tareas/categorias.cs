﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicacion_de_tareas
{
    public partial class categorias : Form
    {
        string cadena = "Data Source=DESKTOP-71D4CHF\\MSSQLSERVER01;Initial Catalog=TareasDB;Integrated Security=True";
        Conexionbd conexion = new Conexionbd();
        public SqlConnection conectar = new SqlConnection();
        public SqlCommand comando = new SqlCommand();
        public string id,uss;
       

       

        public void actualizarc()
        {
            string consulta = "select * from Categorias";
            SqlDataAdapter adapter = new SqlDataAdapter(consulta, cadena);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            vista.DataSource = dt;

        }
        public categorias(string us)
        {
            uss = us;
            conectar.ConnectionString = cadena;
            InitializeComponent();
            actualizarc();
        }

        private void btnv_Click(object sender, EventArgs e)
        {
            string us = uss;
            App app = new App(us);
            this.Hide();
            app.Show();
        }

        private void categorias_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nomb = nom.Text;
            string desc = des.Text;
            string fec = fe.Value.ToString("yyyy-MM-dd");
            conexion.add(nomb,desc,fec);
            actualizarc();
            
        }

        public void vista_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int indice = e.RowIndex;
             id= vista.Rows[indice].Cells[0].Value.ToString();
             nom.Text = vista.Rows[indice].Cells[1].Value.ToString();
             des.Text = vista.Rows[indice].Cells[2].Value.ToString();
             fe.Text= vista.Rows[indice].Cells[3].Value.ToString();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int idd;
            int.TryParse(id, out idd);
            conexion.delete(idd);
            actualizarc();

        }

        private void btneditar_Click(object sender, EventArgs e)
        {
            string nomb = nom.Text;
            string desc = des.Text;
            string fec = fe.Value.ToString("yyyy-MM-dd");
            int idd;
            int.TryParse(id, out idd);
            conexion.edi(nomb,desc,fec,idd);
            actualizarc();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
